#!/bin/sh
java -jar maven-assembly-plugin.jar