package net.petrikainulainen.mavenassemblyplugin;

import org.apache.log4j.Logger;

/**
 * Hello world!
 *
 */
public class HelloWorldApp
{
    private static Logger LOGGER = Logger.getLogger(HelloWorldApp.class);

    public static void main( String[] args )
    {
        LOGGER.info("Hello World!");
    }
}
