This an example application of my blog entry:

* [Creating a Runnable Binary Distribution With Maven Assembly Plugin](http://www.petrikainulainen.net/programming/tips-and-tricks/creating-a-runnable-binary-distribution-with-maven-assembly-plugin/)

You can create the binary distribution by running one of the following command at command prompt:

        mvn package assembly:single

        mvn assembly:assembly (invokes the package phase)
