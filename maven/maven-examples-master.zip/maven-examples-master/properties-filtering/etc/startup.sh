#!/bin/sh
java -jar maven-properties-filtering.jar