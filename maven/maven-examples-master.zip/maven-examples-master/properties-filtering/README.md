This is an example application of my blog post:

* [Creating Profile Specific Configuration Files With Maven](http://www.petrikainulainen.net/programming/tips-and-tricks/creating-profile-specific-configuration-files-with-maven/)