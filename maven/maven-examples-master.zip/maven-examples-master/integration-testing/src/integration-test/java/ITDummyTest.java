import org.junit.Test;

import static junit.framework.Assert.assertTrue;

/**
 * @author Petri Kainulainen
 */
public class ITDummyTest {

    @Test
    public void dummyTest() {
        assertTrue(true);
    }
}
