import org.junit.Test;

import static junit.framework.Assert.assertTrue;

/**
 * @author Petri Kainulainen
 */
public class DummyUnitTest {

    @Test
    public void dummyTest() {
        assertTrue(true);
    }
}
